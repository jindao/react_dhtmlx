Scheduler for React.JS
===================

This is an example of an Appointment scheduler component for React that is made with the help of dhtmlxScheduler. 

More features can be added due to rich functionality of dhtmlxScheduler: https://docs.dhtmlx.com/scheduler/guides.html

### How to start

 - clone the repository or download files
 - install dependencies
~~~
yarn install
~~~
or
~~~ 
npm install 
~~~

 - run server
~~~
yarn start
~~~
or
~~~
npm start
~~~

###  Related resources

- Read full tutorial here: [coming soon]
- Learn about dhtmlxScheduler here: https://dhtmlx.com/docs/products/dhtmlxScheduler/
- Learn about React here: https://facebook.github.io/react/