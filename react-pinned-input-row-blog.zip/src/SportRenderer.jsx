import React from 'react';

export default (props) => {
  const sportIconMap = {
    Swimming: 'swimming',
    Gymnastics: 'running',
    Cycling: 'biking',
    'Ski Jumping': 'skiing',
  };

  function getValueToDisplay(params) {
    return params.valueFormatted ? params.valueFormatted : params.value;
  }



  
  return (
    <span>
      <i className={'fa-solid fa-person-' + sportIconMap[props.value]}></i>
      <span style={{ marginLeft: '5px' }}>{getValueToDisplay(props)}</span>
    </span>
  );
};
