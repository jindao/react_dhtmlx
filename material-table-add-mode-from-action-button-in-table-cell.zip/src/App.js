import React, { Fragment, useState } from "react";
import MaterialTable, { MTableAction } from "material-table";
import AddIcon from "@material-ui/icons/AddAlarm";
import IconButton from "@material-ui/core/IconButton";

export default function CustomEditComponent(props) {
  const tableRef = React.createRef();
  const addActionRef = React.useRef();

  const tableColumns = [
    { title: "Client", field: "client" },
    { title: "Name", field: "name" },
    { title: "Year", field: "year" },
    {
      title: "Custom Add",
      field: "internal_action",
      editable: false,
      render: (rowData) =>
        rowData && (
          <IconButton
            color="secondary"
            onClick={() => addActionRef.current.click()}
          >
            <AddIcon />
          </IconButton>
        )
    }
  ];

  const [tableData, setTableData] = useState([
    {
      client: "client1",
      name: "Mary",
      year: "2019"
    },
    {
      client: "client2",
      name: "Yang",
      year: "2018"
    },
    {
      client: "client3",
      name: "Kal",
      year: "2019"
    }
  ]);

  return (
    <Fragment>
      <MaterialTable
        tableRef={tableRef}
        columns={tableColumns}
        data={tableData}
        title="Custom Add Mode"
        options={{
          search: false
        }}
        components={{
          Action: (props) => {
            //If isn't the add action
            console.log(props.action);
            if (
              typeof props.action === typeof Function ||
              props.action.tooltip !== "Add"
            ) {
              return <MTableAction {...props} />;
            } else {
              return <div ref={addActionRef} onClick={props.action.onClick} />;
            }
          }
        }}
        actions={[
          {
            icon: "save",
            tooltip: "Save User",
            onClick: (event, rowData) => alert("You saved " + rowData.name)
          }
        ]}
        editable={{
          onRowAdd: (newData) =>
            Promise.resolve(setTableData([...tableData, newData]))
        }}
      />
    </Fragment>
  );
}
